package com.example.tipcalculator;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText etBillAmount;
    private TextView tvResult;
    private Button btn15, btn18, btn20;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Link UI elements
        etBillAmount = findViewById(R.id.et_bill_amount);
        tvResult = findViewById(R.id.tv_result);
        btn15 = findViewById(R.id.b_15);
        btn18 = findViewById(R.id.b_18);
        btn20 = findViewById(R.id.b_20);

        // Set button click listeners
        btn15.setOnClickListener(v -> calculateTip(15));
        btn18.setOnClickListener(v -> calculateTip(18));
        btn20.setOnClickListener(v -> calculateTip(20));
    }

    private void calculateTip(double percentage) {
        String billAmountStr = etBillAmount.getText().toString();

        if (TextUtils.isEmpty(billAmountStr)) {
            Toast.makeText(this, "Please enter a valid bill amount", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            double billAmount = Double.parseDouble(billAmountStr);
            double tip = billAmount * (percentage / 100);
            double total = billAmount + tip;

            tvResult.setText(String.format("Tip: $%.2f, Total Bill: $%.2f", tip, total));
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Invalid input", Toast.LENGTH_SHORT).show();
        }
    }
}
